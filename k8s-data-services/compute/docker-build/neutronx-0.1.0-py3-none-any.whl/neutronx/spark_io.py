from __future__ import annotations

from typing import Any

from .config import MinioConfig
from .minio_client import s3a_path
from .retry import safe_call
from .result import Result


def configure_s3a(spark: Any, config: MinioConfig) -> Result[dict[str, str]]:
    def _call() -> dict[str, str]:
        if not config.endpoint:
            raise ValueError("MinIO endpoint is required")
        if not config.access_key:
            raise ValueError("MinIO access_key is required")
        if not config.secret_key:
            raise ValueError("MinIO secret_key is required")

        hconf = spark.sparkContext._jsc.hadoopConfiguration()

        endpoint = config.endpoint
        if not endpoint.startswith("http://") and not endpoint.startswith("https://"):
            endpoint = f"{config.s3a_endpoint_protocol}://{endpoint}"

        settings = {
            "fs.s3a.endpoint": endpoint,
            "fs.s3a.access.key": config.access_key,
            "fs.s3a.secret.key": config.secret_key,
            "fs.s3a.path.style.access": "true",
            "fs.s3a.connection.ssl.enabled": str(config.secure).lower(),
            "fs.s3a.impl": "org.apache.hadoop.fs.s3a.S3AFileSystem",
        }
        if config.region:
            settings["fs.s3a.endpoint.region"] = config.region

        for k, v in settings.items():
            hconf.set(k, v)

        return {
            k: ("***REDACTED***" if "key" in k else v)
            for k, v in settings.items()
        }

    return safe_call(component="spark_io", operation="configure_s3a", fn=_call)


def read_minio_parquet(spark: Any, *, bucket: str, key: str, **options: Any) -> Result[Any]:
    def _call() -> Any:
        reader = spark.read
        for k, v in options.items():
            reader = reader.option(k, v)
        return reader.parquet(s3a_path(bucket, key))

    return safe_call(
        component="spark_io",
        operation="read_minio_parquet",
        fn=_call,
        details={"bucket": bucket, "key": key},
    )


def write_minio_parquet(
    df: Any,
    *,
    bucket: str,
    key: str,
    mode: str = "error",
    partition_by: list[str] | None = None,
    **options: Any,
) -> Result[str]:
    def _call() -> str:
        writer = df.write.mode(mode)
        for k, v in options.items():
            writer = writer.option(k, v)
        if partition_by:
            writer = writer.partitionBy(*partition_by)
        path = s3a_path(bucket, key)
        writer.parquet(path)
        return path

    return safe_call(
        component="spark_io",
        operation="write_minio_parquet",
        fn=_call,
        details={"bucket": bucket, "key": key, "mode": mode},
    )


def read_minio_delta(spark: Any, *, bucket: str, key: str, **options: Any) -> Result[Any]:
    def _call() -> Any:
        reader = spark.read.format("delta")
        for k, v in options.items():
            reader = reader.option(k, v)
        return reader.load(s3a_path(bucket, key))

    return safe_call(
        component="spark_io",
        operation="read_minio_delta",
        fn=_call,
        details={"bucket": bucket, "key": key},
    )


def write_minio_delta(
    df: Any,
    *,
    bucket: str,
    key: str,
    mode: str = "error",
    partition_by: list[str] | None = None,
    **options: Any,
) -> Result[str]:
    def _call() -> str:
        writer = df.write.format("delta").mode(mode)
        for k, v in options.items():
            writer = writer.option(k, v)
        if partition_by:
            writer = writer.partitionBy(*partition_by)
        path = s3a_path(bucket, key)
        writer.save(path)
        return path

    return safe_call(
        component="spark_io",
        operation="write_minio_delta",
        fn=_call,
        details={"bucket": bucket, "key": key, "mode": mode},
    )
