from __future__ import annotations

import random
import time
from typing import Callable, TypeVar

from .errors import PlatformError
from .result import Result

T = TypeVar("T")


def safe_call(
    *,
    component: str,
    operation: str,
    fn: Callable[[], T],
    details: dict | None = None,
    retriable: bool = False,
) -> Result[T]:
    try:
        return Result.success(fn())
    except Exception as exc:
        return Result.fail(
            PlatformError.from_exception(
                component=component,
                operation=operation,
                exc=exc,
                details=details,
                retriable=retriable,
            )
        )


def retry_result(
    *,
    component: str,
    operation: str,
    fn: Callable[[], T],
    attempts: int = 3,
    base_sleep_seconds: float = 0.5,
    max_sleep_seconds: float = 5.0,
    details: dict | None = None,
) -> Result[T]:
    last_error: PlatformError | None = None

    for i in range(attempts):
        result = safe_call(
            component=component,
            operation=operation,
            fn=fn,
            details={**(details or {}), "attempt": i + 1, "attempts": attempts},
            retriable=True,
        )
        if result.ok:
            return result

        last_error = result.error
        if i < attempts - 1:
            sleep_s = min(max_sleep_seconds, base_sleep_seconds * (2**i))
            sleep_s = sleep_s + random.uniform(0, sleep_s * 0.2)
            time.sleep(sleep_s)

    return Result.fail(
        last_error
        or PlatformError(
            component=component,
            operation=operation,
            message="operation failed without captured error",
            details=details or {},
            retriable=True,
        )
    )
