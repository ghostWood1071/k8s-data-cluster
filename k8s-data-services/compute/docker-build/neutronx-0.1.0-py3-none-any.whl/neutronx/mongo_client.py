from __future__ import annotations

from typing import Any

from .config import MongoConfig
from .retry import safe_call
from .result import Result


def make_mongo_client(config: MongoConfig) -> Result[Any]:
    def _call() -> Any:
        if not config.uri:
            raise ValueError("MongoDB uri is required")
        from pymongo import MongoClient

        return MongoClient(config.uri, serverSelectionTimeoutMS=config.timeout_ms)

    return safe_call(component="mongo", operation="make_client", fn=_call)


def get_database(config: MongoConfig) -> Result[Any]:
    client_result = make_mongo_client(config)
    if client_result.failed:
        return Result.fail(client_result.error)

    def _call() -> Any:
        if not config.database:
            raise ValueError("MongoDB database is required")
        client = client_result.unwrap()
        client.admin.command("ping")
        return client[config.database]

    return safe_call(component="mongo", operation="get_database", fn=_call)


def insert_one(
    config: MongoConfig,
    *,
    collection: str,
    document: dict[str, Any],
) -> Result[str]:
    db_result = get_database(config)
    if db_result.failed:
        return Result.fail(db_result.error)

    def _call() -> str:
        result = db_result.unwrap()[collection].insert_one(document)
        return str(result.inserted_id)

    return safe_call(
        component="mongo",
        operation="insert_one",
        fn=_call,
        details={"collection": collection},
    )


def find_one(
    config: MongoConfig,
    *,
    collection: str,
    filter_query: dict[str, Any],
    projection: dict[str, Any] | None = None,
) -> Result[dict[str, Any] | None]:
    db_result = get_database(config)
    if db_result.failed:
        return Result.fail(db_result.error)

    def _call() -> dict[str, Any] | None:
        doc = db_result.unwrap()[collection].find_one(filter_query, projection)
        if doc and "_id" in doc:
            doc["_id"] = str(doc["_id"])
        return doc

    return safe_call(
        component="mongo",
        operation="find_one",
        fn=_call,
        details={"collection": collection, "filter_query": filter_query},
    )


def update_one(
    config: MongoConfig,
    *,
    collection: str,
    filter_query: dict[str, Any],
    update: dict[str, Any],
    upsert: bool = False,
) -> Result[dict[str, Any]]:
    db_result = get_database(config)
    if db_result.failed:
        return Result.fail(db_result.error)

    def _call() -> dict[str, Any]:
        result = db_result.unwrap()[collection].update_one(filter_query, update, upsert=upsert)
        return {
            "matched_count": result.matched_count,
            "modified_count": result.modified_count,
            "upserted_id": str(result.upserted_id) if result.upserted_id else None,
        }

    return safe_call(
        component="mongo",
        operation="update_one",
        fn=_call,
        details={"collection": collection, "filter_query": filter_query},
    )
