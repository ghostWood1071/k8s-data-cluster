from __future__ import annotations

import json
from io import BytesIO
from typing import Any

from .config import MinioConfig
from .errors import PlatformError
from .retry import retry_result, safe_call
from .result import Result


def make_minio_client(config: MinioConfig) -> Result[Any]:
    def _call() -> Any:
        if not config.endpoint:
            raise ValueError("MinIO endpoint is required")
        if not config.access_key:
            raise ValueError("MinIO access_key is required")
        if not config.secret_key:
            raise ValueError("MinIO secret_key is required")

        from minio import Minio  # type: ignore

        return Minio(
            endpoint=config.endpoint,
            access_key=config.access_key,
            secret_key=config.secret_key,
            secure=config.secure,
            region=config.region,
        )

    return safe_call(component="minio", operation="make_client", fn=_call)


def ensure_bucket(config: MinioConfig, bucket: str) -> Result[bool]:
    client_result = make_minio_client(config)
    if client_result.failed:
        return Result.fail(client_result.error)

    def _call() -> bool:
        client = client_result.unwrap()
        if not client.bucket_exists(bucket):
            client.make_bucket(bucket)
            return True
        return False

    return retry_result(
        component="minio",
        operation="ensure_bucket",
        fn=_call,
        details={"bucket": bucket},
    )


def put_bytes(
    config: MinioConfig,
    *,
    bucket: str,
    object_name: str,
    data: bytes,
    content_type: str = "application/octet-stream",
    create_bucket: bool = False,
) -> Result[dict[str, Any]]:
    if create_bucket:
        bucket_result = ensure_bucket(config, bucket)
        if bucket_result.failed:
            return Result.fail(bucket_result.error)

    client_result = make_minio_client(config)
    if client_result.failed:
        return Result.fail(client_result.error)

    def _call() -> dict[str, Any]:
        client = client_result.unwrap()
        result = client.put_object(
            bucket_name=bucket,
            object_name=object_name,
            data=BytesIO(data),
            length=len(data),
            content_type=content_type,
        )
        return {
            "bucket": bucket,
            "object_name": object_name,
            "etag": getattr(result, "etag", None),
            "version_id": getattr(result, "version_id", None),
        }

    return retry_result(
        component="minio",
        operation="put_bytes",
        fn=_call,
        details={"bucket": bucket, "object_name": object_name},
    )


def get_bytes(config: MinioConfig, *, bucket: str, object_name: str) -> Result[bytes]:
    client_result = make_minio_client(config)
    if client_result.failed:
        return Result.fail(client_result.error)

    def _call() -> bytes:
        client = client_result.unwrap()
        response = client.get_object(bucket, object_name)
        try:
            return response.read()
        finally:
            response.close()
            response.release_conn()

    return retry_result(
        component="minio",
        operation="get_bytes",
        fn=_call,
        details={"bucket": bucket, "object_name": object_name},
    )


def download_file(
    config: MinioConfig, *, bucket: str, object_name: str, file_path: str
) -> Result[str]:
    client_result = make_minio_client(config)
    if client_result.failed:
        return Result.fail(client_result.error)

    def _call() -> str:
        client = client_result.unwrap()
        client.fget_object(bucket, object_name, file_path)
        return file_path

    return retry_result(
        component="minio",
        operation="download_file",
        fn=_call,
        details={"bucket": bucket, "object_name": object_name, "file_path": file_path},
    )


def put_json(
    config: MinioConfig,
    *,
    bucket: str,
    object_name: str,
    payload: dict[str, Any] | list[Any],
    create_bucket: bool = False,
) -> Result[dict[str, Any]]:
    data = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    return put_bytes(
        config,
        bucket=bucket,
        object_name=object_name,
        data=data,
        content_type="application/json",
        create_bucket=create_bucket,
    )


def get_json(config: MinioConfig, *, bucket: str, object_name: str) -> Result[Any]:
    bytes_result = get_bytes(config, bucket=bucket, object_name=object_name)
    if bytes_result.failed:
        return Result.fail(bytes_result.error)

    return safe_call(
        component="minio",
        operation="parse_json",
        fn=lambda: json.loads(bytes_result.unwrap().decode("utf-8")),
        details={"bucket": bucket, "object_name": object_name},
    )


def object_exists(config: MinioConfig, *, bucket: str, object_name: str) -> Result[bool]:
    client_result = make_minio_client(config)
    if client_result.failed:
        return Result.fail(client_result.error)

    def _call() -> bool:
        client = client_result.unwrap()
        try:
            client.stat_object(bucket, object_name)
            return True
        except Exception as exc:
            # MinIO SDK raises S3Error for not found. Avoid importing SDK exceptions at module load.
            if exc.__class__.__name__ == "S3Error" and getattr(exc, "code", None) in {
                "NoSuchKey",
                "NoSuchObject",
                "NoSuchBucket",
            }:
                return False
            raise

    return retry_result(
        component="minio",
        operation="object_exists",
        fn=_call,
        details={"bucket": bucket, "object_name": object_name},
    )


def s3a_path(bucket: str, key: str) -> str:
    return f"s3a://{bucket}/{key.lstrip('/')}"
