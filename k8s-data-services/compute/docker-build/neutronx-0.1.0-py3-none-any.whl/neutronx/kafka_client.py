from __future__ import annotations

import json
from typing import Any

from .config import KafkaConfig
from .retry import safe_call
from .result import Result


def make_producer(config: KafkaConfig) -> Result[Any]:
    def _call() -> Any:
        if not config.bootstrap_servers:
            raise ValueError("Kafka bootstrap_servers is required")
        from confluent_kafka import Producer

        return Producer(config.to_confluent_config())

    return safe_call(component="kafka", operation="make_producer", fn=_call)


def produce_json(
    config: KafkaConfig,
    *,
    topic: str,
    key: str | bytes | None,
    value: dict[str, Any] | list[Any],
    headers: dict[str, str] | None = None,
    flush_timeout_seconds: float = 10.0,
) -> Result[dict[str, Any]]:
    producer_result = make_producer(config)
    if producer_result.failed:
        return Result.fail(producer_result.error)

    def _call() -> dict[str, Any]:
        producer = producer_result.unwrap()
        delivery: dict[str, Any] = {"delivered": False, "error": None}

        def callback(err: Any, msg: Any) -> None:
            if err is not None:
                delivery["error"] = str(err)
                return
            delivery.update(
                {
                    "delivered": True,
                    "topic": msg.topic(),
                    "partition": msg.partition(),
                    "offset": msg.offset(),
                }
            )

        producer.produce(
            topic=topic,
            key=key,
            value=json.dumps(value, ensure_ascii=False).encode("utf-8"),
            headers=headers,
            callback=callback,
        )
        producer.flush(flush_timeout_seconds)

        if delivery.get("error"):
            raise RuntimeError(delivery["error"])
        if not delivery.get("delivered"):
            raise TimeoutError("Kafka message was not delivered before flush timeout")
        return delivery

    return safe_call(
        component="kafka",
        operation="produce_json",
        fn=_call,
        details={"topic": topic},
        retriable=True,
    )
