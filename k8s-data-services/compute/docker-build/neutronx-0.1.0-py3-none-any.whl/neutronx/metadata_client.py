from __future__ import annotations

from typing import Any

from .config import ApiConfig, OpenMetadataConfig
from .http_client import get_json, request_json
from .result import Result


def _headers(config: OpenMetadataConfig) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if config.token:
        headers["Authorization"] = f"Bearer {config.token}"
    return headers


def _api_config(config: OpenMetadataConfig) -> ApiConfig:
    return ApiConfig(
        timeout_seconds=config.timeout_seconds,
        verify_tls=config.verify_tls,
    )


def openmetadata_get(
    config: OpenMetadataConfig,
    *,
    path: str,
    params: dict[str, Any] | None = None,
) -> Result[Any]:
    if not config.base_url:
        from .errors import PlatformError
        return Result.fail(
            PlatformError(
                component="openmetadata",
                operation="get",
                message="OpenMetadata base_url is required",
            )
        )

    url = f"{config.base_url.rstrip('/')}/api/v1/{path.lstrip('/')}"
    return get_json(
        url,
        params=params,
        headers=_headers(config),
        api_config=_api_config(config),
    )


def openmetadata_request(
    config: OpenMetadataConfig,
    *,
    method: str,
    path: str,
    payload: dict[str, Any] | list[Any] | None = None,
) -> Result[Any]:
    if not config.base_url:
        from .errors import PlatformError
        return Result.fail(
            PlatformError(
                component="openmetadata",
                operation=method,
                message="OpenMetadata base_url is required",
            )
        )

    url = f"{config.base_url.rstrip('/')}/api/v1/{path.lstrip('/')}"
    return request_json(
        method=method,
        url=url,
        payload=payload,
        headers=_headers(config),
        api_config=_api_config(config),
    )


def openmetadata_create_or_update(
    config: OpenMetadataConfig,
    *,
    entity_path: str,
    payload: dict[str, Any],
) -> Result[Any]:
    # OpenMetadata has entity-specific APIs. This function intentionally stays generic.
    return openmetadata_request(
        config,
        method="PUT",
        path=entity_path,
        payload=payload,
    )
