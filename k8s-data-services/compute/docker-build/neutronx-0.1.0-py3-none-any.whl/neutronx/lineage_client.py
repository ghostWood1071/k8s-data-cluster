from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from .config import ApiConfig, OpenLineageConfig
from .errors import PlatformError
from .http_client import post_json
from .result import Result


def build_openlineage_event(
    *,
    config: OpenLineageConfig,
    job_name: str,
    event_type: str,
    run_id: str | None = None,
    inputs: list[dict[str, Any]] | None = None,
    outputs: list[dict[str, Any]] | None = None,
    facets: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "eventType": event_type.upper(),
        "eventTime": datetime.now(timezone.utc).isoformat(),
        "run": {
            "runId": run_id or str(uuid4()),
            "facets": (facets or {}).get("run", {}),
        },
        "job": {
            "namespace": config.namespace,
            "name": job_name,
            "facets": (facets or {}).get("job", {}),
        },
        "inputs": inputs or [],
        "outputs": outputs or [],
        "producer": "https://github.com/local/neutronx",
        "schemaURL": "https://openlineage.io/spec/1-0-5/OpenLineage.json",
    }


def emit_openlineage_event(
    config: OpenLineageConfig,
    *,
    event: dict[str, Any],
) -> Result[Any]:
    if not config.endpoint:
        return Result.fail(
            PlatformError(
                component="openlineage",
                operation="emit_event",
                message="OpenLineage endpoint is required",
            )
        )

    url = f"{config.endpoint.rstrip('/')}/api/v1/lineage"
    return post_json(
        url,
        payload=event,
        api_config=ApiConfig(
            timeout_seconds=config.timeout_seconds,
            verify_tls=config.verify_tls,
        ),
    )


def emit_job_event(
    config: OpenLineageConfig,
    *,
    job_name: str,
    event_type: str,
    run_id: str | None = None,
    inputs: list[dict[str, Any]] | None = None,
    outputs: list[dict[str, Any]] | None = None,
    facets: dict[str, Any] | None = None,
) -> Result[Any]:
    event = build_openlineage_event(
        config=config,
        job_name=job_name,
        event_type=event_type,
        run_id=run_id,
        inputs=inputs,
        outputs=outputs,
        facets=facets,
    )
    return emit_openlineage_event(config, event=event)
