from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass(frozen=True)
class PlatformError:
    component: str
    operation: str
    message: str
    details: dict[str, Any] = field(default_factory=dict)
    cause_type: str | None = None
    retriable: bool = False
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    @classmethod
    def from_exception(
        cls,
        *,
        component: str,
        operation: str,
        exc: Exception,
        details: dict[str, Any] | None = None,
        retriable: bool = False,
    ) -> "PlatformError":
        return cls(
            component=component,
            operation=operation,
            message=str(exc),
            details=details or {},
            cause_type=exc.__class__.__name__,
            retriable=retriable,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "component": self.component,
            "operation": self.operation,
            "message": self.message,
            "details": self.details,
            "cause_type": self.cause_type,
            "retriable": self.retriable,
            "timestamp": self.timestamp,
        }


class PlatformException(Exception):
    def __init__(self, error: PlatformError) -> None:
        super().__init__(error.message)
        self.error = error
