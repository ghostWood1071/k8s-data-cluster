from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from . import airflow_client, hive_client, kafka_client, k8s_client, metadata_client
from . import minio_client, mongo_client, spark_io
from .config import PlatformConfig
from .lineage_client import emit_job_event
from .result import Result


@dataclass
class PlatformContext:
    spark: Any
    config: PlatformConfig

    @classmethod
    def from_env(cls, spark: Any) -> "PlatformContext":
        return cls(spark=spark, config=PlatformConfig.from_env())

    # Spark + MinIO / S3A
    def configure_s3a(self) -> Result[dict[str, str]]:
        return spark_io.configure_s3a(self.spark, self.config.minio)

    def read_minio_parquet(self, bucket: str, key: str, **options: Any) -> Result[Any]:
        return spark_io.read_minio_parquet(self.spark, bucket=bucket, key=key, **options)

    def write_minio_parquet(
        self,
        df: Any,
        bucket: str,
        key: str,
        mode: str = "error",
        partition_by: list[str] | None = None,
        **options: Any,
    ) -> Result[str]:
        return spark_io.write_minio_parquet(
            df,
            bucket=bucket,
            key=key,
            mode=mode,
            partition_by=partition_by,
            **options,
        )

    def read_minio_delta(self, bucket: str, key: str, **options: Any) -> Result[Any]:
        return spark_io.read_minio_delta(self.spark, bucket=bucket, key=key, **options)

    def write_minio_delta(
        self,
        df: Any,
        bucket: str,
        key: str,
        mode: str = "error",
        partition_by: list[str] | None = None,
        **options: Any,
    ) -> Result[str]:
        return spark_io.write_minio_delta(
            df,
            bucket=bucket,
            key=key,
            mode=mode,
            partition_by=partition_by,
            **options,
        )

    # MinIO SDK
    def put_minio_json(
        self,
        bucket: str,
        object_name: str,
        payload: dict[str, Any] | list[Any],
        create_bucket: bool = False,
    ) -> Result[dict[str, Any]]:
        return minio_client.put_json(
            self.config.minio,
            bucket=bucket,
            object_name=object_name,
            payload=payload,
            create_bucket=create_bucket,
        )

    def get_minio_json(self, bucket: str, object_name: str) -> Result[Any]:
        return minio_client.get_json(
            self.config.minio,
            bucket=bucket,
            object_name=object_name,
        )

    def download_minio_file(self, bucket: str, object_name: str, file_path: str) -> Result[str]:
        return minio_client.download_file(
            self.config.minio,
            bucket=bucket,
            object_name=object_name,
            file_path=file_path,
        )

    # Airflow
    def trigger_airflow_dag(
        self,
        dag_id: str,
        conf: dict[str, Any] | None = None,
        dag_run_id: str | None = None,
    ) -> Result[Any]:
        return airflow_client.trigger_dag(
            self.config.airflow,
            dag_id=dag_id,
            conf=conf,
            dag_run_id=dag_run_id,
        )

    def get_airflow_dag_run(self, dag_id: str, dag_run_id: str) -> Result[Any]:
        return airflow_client.get_dag_run(
            self.config.airflow,
            dag_id=dag_id,
            dag_run_id=dag_run_id,
        )

    # Kafka
    def emit_kafka_json(
        self,
        topic: str,
        key: str | bytes | None,
        value: dict[str, Any] | list[Any],
        headers: dict[str, str] | None = None,
    ) -> Result[dict[str, Any]]:
        return kafka_client.produce_json(
            self.config.kafka,
            topic=topic,
            key=key,
            value=value,
            headers=headers,
        )

    # MongoDB
    def mongo_insert_one(
        self,
        collection: str,
        document: dict[str, Any],
    ) -> Result[str]:
        return mongo_client.insert_one(
            self.config.mongo,
            collection=collection,
            document=document,
        )

    def mongo_find_one(
        self,
        collection: str,
        filter_query: dict[str, Any],
        projection: dict[str, Any] | None = None,
    ) -> Result[dict[str, Any] | None]:
        return mongo_client.find_one(
            self.config.mongo,
            collection=collection,
            filter_query=filter_query,
            projection=projection,
        )

    def mongo_update_one(
        self,
        collection: str,
        filter_query: dict[str, Any],
        update: dict[str, Any],
        upsert: bool = False,
    ) -> Result[dict[str, Any]]:
        return mongo_client.update_one(
            self.config.mongo,
            collection=collection,
            filter_query=filter_query,
            update=update,
            upsert=upsert,
        )

    # K8s CRD / Operator
    def patch_cr_status(
        self,
        *,
        group: str,
        version: str,
        plural: str,
        name: str,
        status: dict[str, Any],
        namespace: str | None = None,
    ) -> Result[dict[str, Any]]:
        return k8s_client.patch_custom_object_status(
            self.config.k8s,
            group=group,
            version=version,
            plural=plural,
            name=name,
            status=status,
            namespace=namespace,
        )

    def create_cr(
        self,
        *,
        group: str,
        version: str,
        plural: str,
        body: dict[str, Any],
        namespace: str | None = None,
    ) -> Result[dict[str, Any]]:
        return k8s_client.create_custom_object(
            self.config.k8s,
            group=group,
            version=version,
            plural=plural,
            body=body,
            namespace=namespace,
        )

    # Hive
    def execute_hive(self, sql: str, fetch: bool = True) -> Result[list[tuple] | int]:
        return hive_client.execute_hive(
            self.config.hive,
            sql=sql,
            fetch=fetch,
        )

    # OpenMetadata
    def openmetadata_get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> Result[Any]:
        return metadata_client.openmetadata_get(
            self.config.openmetadata,
            path=path,
            params=params,
        )

    def openmetadata_create_or_update(
        self,
        entity_path: str,
        payload: dict[str, Any],
    ) -> Result[Any]:
        return metadata_client.openmetadata_create_or_update(
            self.config.openmetadata,
            entity_path=entity_path,
            payload=payload,
        )

    # OpenLineage
    def emit_lineage_event(
        self,
        *,
        job_name: str,
        event_type: str,
        run_id: str | None = None,
        inputs: list[dict[str, Any]] | None = None,
        outputs: list[dict[str, Any]] | None = None,
        facets: dict[str, Any] | None = None,
    ) -> Result[Any]:
        return emit_job_event(
            self.config.openlineage,
            job_name=job_name,
            event_type=event_type,
            run_id=run_id,
            inputs=inputs,
            outputs=outputs,
            facets=facets,
        )
